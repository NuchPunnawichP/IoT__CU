/*
 * MG90S.h
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#ifndef MG90S_H_
#define MG90S_H_

#include "main.h"

class MG90S
{
public:

	void Feed(uint32_t call);
	void ReverseFeed(uint32_t call);
	void stop();
};


#endif /* MG90S_H_ */
