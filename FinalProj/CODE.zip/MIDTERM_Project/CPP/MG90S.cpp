/*
 * MG90S.cpp
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#include "MG90S.h"

extern TIM_HandleTypeDef htim3;

#define SERVO_CW 50
#define SERVO_CCW 100
#define SERVO_STOP 75

void MG90S::Feed(uint32_t call)
{
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, SERVO_CW);
	HAL_Delay((uint32_t)(210 * call / 90));
	stop();
}

void MG90S::ReverseFeed(uint32_t call)
{
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, SERVO_CCW);
	HAL_Delay((uint32_t)(210 * call / 90));
	stop();
}

void MG90S::stop()
{
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, SERVO_STOP);
}

