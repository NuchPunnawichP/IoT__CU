/*
 * CPPmain.h
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#ifndef CPPMAIN_H_
#define CPPMAIN_H_


#include "main.h"
#ifdef __cplusplus
extern "C" {
#endif

void setup();
void loop();
void gpio_init();

#ifdef __cplusplus
}
#endif


#endif /* CPPMAIN_H_ */
