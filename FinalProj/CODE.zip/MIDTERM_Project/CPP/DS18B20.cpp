/*
 * DS18B20.cpp
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#include "DS18B20.h"

uint32_t cnt = 0;
uint8_t scratchPad[9];

void Delay_us(uint32_t us)
{
	uint32_t startTime = TIM2->CNT;
	uint32_t countTime = us*16;
	while(TIM2->CNT - startTime < countTime);
}

void startInitial()
{
	HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_RESET);
	Delay_us(500);

	HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_SET);

	while(HAL_GPIO_ReadPin(Temp_sensor_GPIO_Port, Temp_sensor_Pin) == GPIO_PIN_RESET);
	while(HAL_GPIO_ReadPin(Temp_sensor_GPIO_Port, Temp_sensor_Pin) == GPIO_PIN_SET);
	uint32_t startTime = TIM2->CNT;

	while(HAL_GPIO_ReadPin(Temp_sensor_GPIO_Port, Temp_sensor_Pin) == GPIO_PIN_RESET);
	cnt = (TIM2->CNT - startTime) / 16;
}

void sendByte(uint8_t data)
{
	// send byte in hex form with LSB
	for(int i=0 ; i<8 ; i++)
	{
		if((data >> i) & 1)
		{
			HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_RESET);
			Delay_us(5);

			HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_SET);
			Delay_us(75);
		}
		else
		{
			HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_RESET);
			Delay_us(65);

			HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_SET);
			Delay_us(15);
		}
	}
}

uint8_t ReadBit()
{
	uint8_t bit_value;

	HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_RESET);
	Delay_us(5);

	HAL_GPIO_WritePin(Temp_sensor_GPIO_Port, Temp_sensor_Pin, GPIO_PIN_SET);
	Delay_us(10);

	bit_value = HAL_GPIO_ReadPin(Temp_sensor_GPIO_Port, Temp_sensor_Pin) == GPIO_PIN_SET;
	Delay_us(50);

	return bit_value;
}

uint8_t ReadByte()
{
	uint8_t byte_value = 0;

	for (int i=0 ; i<8 ; i++)
	{
		byte_value |= (ReadBit() << i);
	}
	return byte_value;
}

void Read_ScratchPad(uint8_t* scratchPadPointer)
{
	for(int i=0 ; i<9 ; i++)
	{
		scratchPadPointer[i] = ReadByte();
	}
}

// Not endianness safe
float ConvertToCelsius(uint8_t* tempPointer)
{
	return *((int16_t*)tempPointer) * 0.0625f;
}

float Read_temp()
{
	Read_ScratchPad(scratchPad);
	return ConvertToCelsius(scratchPad);
}
