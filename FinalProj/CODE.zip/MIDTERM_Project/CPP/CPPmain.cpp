/*
 * CPPmain.cpp
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#include "CPPmain.h"

#include "DS18B20.h"
#include "MG90S.h"
#include "BH1750.h"

#include "stdio.h"

extern I2C_HandleTypeDef hi2c1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart2;

MG90S feed;
BH1750 lightSensor;

float temp = 0;
uint16_t lux = 0;

// EC Sensor
uint32_t adc_value;
float turbidity_value;
char uart_buf[100];  // Increased buffer size
int uart_buf_len;

void setup()
{
	HAL_TIM_Base_Start(&htim2);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);

	lightSensor.BH1750_Init();
	lightSensor.BH1750_Start();
}

void loop()
{
	// Temperature
	startInitial();
	sendByte(0xCC);
	sendByte(0x44);
	HAL_Delay(1000);

	startInitial();
	sendByte(0xCC);
	sendByte(0xBE);

	temp = Read_temp();

	// Feed Fish. 90 degree per call
	// Assign the number of call in the function
	// Feed = CW
	// ReverseFeed = CCW
	feed.Feed(120);
	HAL_Delay(2000);
	feed.ReverseFeed(120);
	HAL_Delay(1000);

	// Light Sensor
	lux = lightSensor.BH1750_ReadLight();

	// EC sensor
	HAL_ADC_Start(&hadc1);
	if (HAL_ADC_PollForConversion(&hadc1, 1000) == HAL_OK)
	{
		adc_value = HAL_ADC_GetValue(&hadc1);

		float voltage = (adc_value * 3.3) / 4096.0;
		turbidity_value = (voltage - 2.5) * -100;

		HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, uart_buf_len, HAL_MAX_DELAY);
	}
}
