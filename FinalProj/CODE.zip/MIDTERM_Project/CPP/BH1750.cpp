/*
 * BH1750.cpp
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#include "BH1750.h"

extern I2C_HandleTypeDef hi2c1;

#define BH1750_ADDRESS (0x23 << 1)
#define BH1750_POWER_ON 0x01
#define BH1750_CONT_H_RES_MODE 0x10

void BH1750::BH1750_Init(void)
{
	uint8_t power = BH1750_POWER_ON;
	HAL_I2C_Master_Transmit(&hi2c1, BH1750_ADDRESS, &power, 1, HAL_MAX_DELAY);
}

void BH1750::BH1750_Start(void)
{
	uint8_t start = BH1750_CONT_H_RES_MODE;

	HAL_I2C_Master_Transmit(&hi2c1, BH1750_ADDRESS, &start, 1, HAL_MAX_DELAY);
}

uint16_t BH1750::BH1750_ReadLight(void)
{
	uint8_t data[2];

	HAL_I2C_Master_Receive(&hi2c1, BH1750_ADDRESS, data, 2, HAL_MAX_DELAY);

	uint16_t lux = (data[0] << 8) | data[1];

	return lux / 1.2;
}

