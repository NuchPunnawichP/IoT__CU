/*
 * BH1750.h
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#ifndef BH1750_H_
#define BH1750_H_

#include "main.h"

class BH1750
{
public:

	void BH1750_Init(void);

	void BH1750_Start(void);

	uint16_t BH1750_ReadLight(void);

};

#endif /* BH1750_H_ */
