/*
 * DS18B20.h
 *
 *  Created on: Oct 5, 2024
 *      Author: Pannawit
 */

#ifndef DS18B20_H_
#define DS18B20_H_

#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

void Delay_us(uint32_t us);
void startInitial();
void sendByte(uint8_t data);
uint8_t ReadBit();
uint8_t ReadByte();
void Read_ScratchPad(uint8_t* scratchPadPointer);
float ConvertToCelsius(uint8_t* tempPointer);
float Read_temp();

extern uint32_t cnt;
extern uint8_t scratchPad[9];

#ifdef __cplusplus
}
#endif


#endif /* DS18B20_H_ */
